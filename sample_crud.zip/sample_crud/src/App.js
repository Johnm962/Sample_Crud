import React,{useState, useEffect} from 'react'
import './App.css';

function App() {
   const [data, setData] = useState({id:"", name:"", email:"",password:""})
   const [table, setTable] = useState([])

   useEffect(() => {
     setTable(table)
   },[table])

   const onChangeHandler = (e) => {
       const {name, value} = e.target
       setData({...data, [name]: value})
   }

   const onClickHandler = (e) => {
     e.preventDefault();
     const id = Math.floor(Math.random() * 100)
     if(data.id === ""){
      setTable([...table,{...data,id:id}]) 
     }else {
      let newIndex = table.findIndex(ind => ind.id === data.id)
      console.log(data)
      table[newIndex] = data
      setTable(table)
     }     
   }

   const onClickEditHandler = (obj) => {
        setData(obj)
   }

   const onClickDeleteHandler = (id) => {
    let newTable = table.filter(obj => obj.id !== id)
    setTable(newTable)
  }


  return (
  <>
   <form>
    <div className="form-group">
      <label htmlFor="exampleInputName">Name</label>
      <input type="text" name="name" className="form-control" placeholder="Enter name" value={data.name}  onChange={onChangeHandler} />
    </div>
    <div className="form-group">
      <label htmlFor="exampleInputEmail1">Email address</label>
      <input type="email" name="email" className="form-control" placeholder="Enter email" value={data.email}  onChange={onChangeHandler} />
    </div>
    <div className="form-group">
      <label htmlFor="exampleInputPassword1">Password</label>
      <input type="password" name="password" className="form-control" placeholder="Password" value={data.password} onChange={onChangeHandler} />
    </div>
    <button type="submit" className="btn btn-primary" onClick={onClickHandler}>Submit</button>
   </form>

   <table className="table">
    <thead className="thead-light">
     <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
      <th scope="col">Edit</th>
      <th scope="col">Delete</th>
     </tr>
    </thead>
    <tbody>
    {table.map((obj, index) => {
      return (
     <tr key={index}>
      <td>{obj.id}</td>
      <td>{obj.name}</td>
      <td>{obj.email}</td>
      <td>{obj.password}</td>
      <td><button className="btn btn-primary" onClick={()=>onClickEditHandler(obj)}>Edit</button></td>
      <td><button className="btn btn-primary" onClick={()=>onClickDeleteHandler(obj.id)}>Delete</button></td>
     </tr>
    )
  })
  }
    </tbody>
   </table>
  </>
 );
}

export default App;
